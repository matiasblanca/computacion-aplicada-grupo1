#!/bin/bash

# Verificar si como argumento se pasa la palabra "help"
if [ "$1" = "-help" ] || [ "$1" = "help"  ]; then
	cat /opt/scripts/backup_full_help.txt
	# En el arhcivo help se encontraría todo el texto de ayuda
	exit 0

# Valida si hay dos argumentos.
elif [ "$#" -ne 2  ]; then
	echo "Uso: $0 <directorio_origen> <directorio_destino> (o -help)"
	exit 1
fi

# Validar que directorios de origen y destino estén disponibles
if [ ! -d "$1" ]; then
	echo "Error: el directorio de origen '$1' no existe o no está disponible."
	exit 1
elif [ ! -d "$2" ]; then
	echo "Error: el directorio de destino '$2' no existe o no está disponible."
	exit 1
fi

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Nombre del archivo de backup
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

# Crear el backup
tar -czf "$2/$BACKUP" -C "$1" .

# Verificar si el backup se creó correctamente
if [ -f "$2/$BACKUP"  ]; then
	echo "Backup creado correctamente: $2/$BACKUP"
else
	echo "Error al crear el backup en $2/$BACKUP"
	exit 1
fi
